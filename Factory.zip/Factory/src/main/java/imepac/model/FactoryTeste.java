/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package imepac.model;
import imepac.calculoIcms.IcmsFactory;
import java.math.BigDecimal;

/**
 *
 * @author Gabriella Rodrigues      
 */
public class FactoryTeste {

    public static void main(String[] args) {
        
       Orcamento orcamento = new Orcamento(new BigDecimal("1000"), "ICMS_MG");
       
       IcmsFactory icmsFactory = new IcmsFactory();
       
       BigDecimal resultado = icmsFactory.getIcmsPorEstado("ICMS_MG").calculoPorRegiao(orcamento);
        System.out.println("Valor ICMS: " + resultado);
    }
}
