 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package imepac.calculoIcms;



/**
 *
 * @author Gabriella Rodrigues
 */
public class IcmsFactory {

    public CalculoPorRegiao getIcmsPorEstado(String nomeEstado) {
        if (nomeEstado.equalsIgnoreCase("ICMS_MG")) {
            return new IcmsMG();
        } else if (nomeEstado.equalsIgnoreCase("ICMS_SP")) {
            return new IcmsSP();
        } else if (nomeEstado.equalsIgnoreCase("ICMS_RJ")) {
            return new IcmsRJ();
        } else if (nomeEstado.equalsIgnoreCase("ICMS_ES")) {
            return new IcmsES();
        } else {
            System.out.println("Estado não cadastrado!");
            return null;
        }
    }
}
    
