/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package imepac.calculoIcms;

import imepac.model.Orcamento;
import java.math.BigDecimal;

/**
 *
 * @author Gabriella Rodrigues
 */
public interface CalculoPorRegiao {
    public BigDecimal calculoPorRegiao(Orcamento orcamento);
}
